**Comment utiliser le programme**

1- Double-cliquez sur le programme.

2- Choisissez la fa�on dont les donn�es sont entr�es dans le programme (automatique = 0; avec un fichier = 1) et appuyez sur Enter.

	a- Si les donn�es sont g�n�r�es automatiquement, choisissez les param�tres N(ombre de donn�es), R(ang/Intervalle), D(�sordre, taux de) et appuyez sur Enter.

	b- Si les donn�es sont charg�es � partir d'un fichier, entrez le nom du fichier ou glisser le fichier dans la console et appuyez sur Enter.

3- Choisissez la fa�on dont les recherches sont entr�es dans le programme (manuellement = 0; avec un fichier = 1) et appuyez sur Enter.

	a- Si les recherches sont charg�es � partir d'un fichier, entrez le nom du fichier ou glisser le fichier dans la console et appuyez sur Enter.

4- Choisissez le nom du fichier de sortie avec son emplacement et appuyez sur Enter.

5- Choississez l'algorithme de recherche qui sera utilis� et appuyez sur Enter.

6- Le programme s'ex�cute. Si vous avez choisi d'entrer les donn�es � la main, taper la valeur de chercher et appuyez sur Enter. Si la valeur existe,
   le programme retourne l'index de cette valeur, sinon elle retourne -1.

7- En mode manuel d'entr�e de recherche, pour quitter le programme, entrer un nombre n�gatif et appuyez sur Enter.

8- Les statistiques s'affichent � l'�cran � la fin de l'ex�cution. Ces statistiques sont aussi pr�sentent dans le fichier de sortie 
   cr�� � la fin de l'ex�cution du programme.



