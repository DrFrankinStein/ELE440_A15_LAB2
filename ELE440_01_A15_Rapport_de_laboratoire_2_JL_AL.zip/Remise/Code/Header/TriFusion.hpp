#ifndef TRI_FUSION_H
#define	TRI_FUSION_H

#include "../Header/CommonFunc.hpp"

Barometre TriParFusion(int Donnees[][2], int indexPremier, int indexDernier);

#endif //TRI_FUSION_H