#ifndef TRI_BASE_H
#define	TRI_BASE_H

#include "../Header/CommonFunc.hpp"

Barometre TriParBase(int Donnees[][2],int taille, int nbreChiffre);

#endif //TRI_BASE_H