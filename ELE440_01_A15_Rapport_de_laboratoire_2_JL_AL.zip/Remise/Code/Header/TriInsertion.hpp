#ifndef TRI_INSERT_H
#define	TRI_INSERT_H

#include "../Header/CommonFunc.hpp"

Barometre TriParInsertion(int Donnees[][2],int taille);

#endif //TRI_INSERT_H