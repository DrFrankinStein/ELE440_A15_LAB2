#include <cstdlib>
#include <iostream>
#include <string>
#include <stdio.h>

#include "../Header/CommonFunc.hpp"

using namespace std;

/**
 * Echange 2 valeurs de places
 * @param a
 * @param b
 */
void swap(int *a, int *b)
{
    int tmp = *a;
    *a=*b;
    *b=tmp;
}

/**
 * Retourne une valeur entre min et max
 * @param min
 * @param max
 * @return 
 */
int randInt(int min, int max)
{
    //srand(time(NULL));
    int range = max-min+1;
    return (rand()%range)+min; 
}

/**
 * Imprime un tableau de int a l'Ecran
 * @param T Tableau a imprimer
 * @param n Taille du tableau
 */
void printIntArray(int* T, int n)
{
    for(int i =0;i<n;i++)
    {
        printf("%i ", T[i]);
    }
    printf("\n\n\r");
}

/**
 * Genere des donnees au "hasard" sans qu'il n'y ait de doublons
 * @param tableau Tableau a remplir
 * @param N Taille du tableau
 * @param R Intervalle des donnees du tableau
 * @param D Taux de desordre du tableau
 */
void GenererDonnees (int *tableau, int N, int R, int D)
{
    srand(time(NULL));
    if (R >= N)
    {
        
        int step = R/N;
        
        int last = 0;
        
        if(step==1)
            last = R-N;
        
        for (int i = 0; i < N; i++)
        {
            tableau[i] = last;
            last = last + step;
            
        }
        if(N>1)
        {
            tableau[0] = randInt(0,tableau[1]-1);
            for (int i = 1; i < N-1; i++)
            {
                tableau[i] = randInt(tableau[i-1]+1,tableau[i+1]-1);
            }
            tableau[N-1] = randInt(tableau[N-2]+1,R);
        }
        else
            tableau[0] = randInt(0,R);
        // Les donnees sont triees
        
        // mettre les donnees en desordre.
        
        int m;
        int M = N/2;
        int i;
        int k;
        int L;
        int Tp[M];
        int iExchange;
        
        for (i = 1; i <= M; i++)
        {
            Tp[i-1] = i;
        }
        
        m = M;
        
        for (i = 1; i <= ((M*D)/100); i++)
        {
            k = (rand() % m);
            L = Tp[k];
            Tp[k]=Tp[m-1];
            m = m - 1;
            
            iExchange = tableau[M-L];
            
            tableau[M-L] = tableau[M+L-1];
            
            tableau[M+L-1] = iExchange;
        }
        
    }
}
